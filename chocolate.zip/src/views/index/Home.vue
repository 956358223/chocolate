<template>
  <el-card shadow="never">
    Gem in the sky.
  </el-card>
</template>

<script>
export default {
  name: "Dashboard"
}
</script>

<style scoped>

</style>