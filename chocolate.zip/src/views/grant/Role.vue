<template>
  <el-card shadow="never">
    Role Vue.
  </el-card>
</template>

<script>
export default {
  name: "Role"
}
</script>

<style scoped>

</style>